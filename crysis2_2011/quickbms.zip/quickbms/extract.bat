%~dp0quickbms.exe "%~dp0Crysis_2_script_0.2.bms" "%~dp0Russian.pak" "%~dp0extracted"
pause