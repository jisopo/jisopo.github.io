cls
mkdir silent
for %%i in (*.mp2) do ffmpeg -i %%i -filter:a "volume=0" -c:a mp2 -b:a 192k -vcodec copy silent\%%i
pause